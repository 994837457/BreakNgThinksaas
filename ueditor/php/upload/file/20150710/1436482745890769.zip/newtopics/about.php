<?php
defined('IN_TS') or die('Access Denied.');
return array(
'name' => '首页最新帖子',
'version' => '1.0',
'desc' => '首页最新帖子',
'url' => 'http://www.mcyami.com/,http://www.breakng.com/',
'email' => '945146147@qq.com',
'author' => '小陈先生,BreakNg',
'author_url' => 'http://www.mcyami.com/,http://www.breakng.com/',
'isedit'	=> '0',
);